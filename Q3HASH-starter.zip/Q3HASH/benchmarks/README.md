# Benchmarks

No published performance figures or hardware claims yet.

Planned protocol: compare semantically equivalent circuits, record dimensions, gate basis, resource costs, simulators/hardware, compiler version, seed, trial counts, confidence intervals and repeatable commands. Report negative results and tradeoffs.
