# Benchmark methodology

No validated performance benchmarks are published at this stage.

Future comparisons must use equivalent workloads and disclose state dimensions,
target hardware assumptions, gate sets, compilation choices, fidelity, resource
accounting, reproducible commands and uncertainty.

The starter simulator does not establish a quantum speedup.
